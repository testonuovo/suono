﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Sapi
        Sapi = CreateObject("sapi.spvoice")
        Sapi.Speak("nella vita non è forte chi non cade mai,ma chi riesce a rialzarsi dopo ogni caduta")
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
