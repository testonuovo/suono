﻿Public Class blocco
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RichTextBox1.SaveFile(Application.StartupPath & "\prova.tc")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        RichTextBox1.LoadFile(Application.StartupPath & "\prova.tc")
    End Sub
End Class