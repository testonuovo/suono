﻿Public Class CustomControl2

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)

        'Inserire qui il codice personalizzato
    End Sub

End Class
