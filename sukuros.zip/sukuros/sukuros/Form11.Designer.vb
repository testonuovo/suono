﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form11
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla mediante l'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        txtNome = New TextBox()
        txtCognome = New TextBox()
        txtIndirizzo = New TextBox()
        txtTelefono = New TextBox()
        Button1 = New Button()
        tabella = New DataGridView()
        CType(tabella, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(67, 27)
        Label1.Name = "Label1"
        Label1.Size = New Size(50, 20)
        Label1.TabIndex = 0
        Label1.Text = "Nome"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(163, 29)
        Label2.Name = "Label2"
        Label2.Size = New Size(74, 20)
        Label2.TabIndex = 1
        Label2.Text = "Cognome"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(278, 27)
        Label3.Name = "Label3"
        Label3.Size = New Size(66, 20)
        Label3.TabIndex = 2
        Label3.Text = "Indirizzo"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(396, 25)
        Label4.Name = "Label4"
        Label4.Size = New Size(67, 20)
        Label4.TabIndex = 3
        Label4.Text = "Telefono"
        ' 
        ' txtNome
        ' 
        txtNome.Location = New Point(37, 74)
        txtNome.Name = "txtNome"
        txtNome.Size = New Size(125, 27)
        txtNome.TabIndex = 4
        ' 
        ' txtCognome
        ' 
        txtCognome.Location = New Point(183, 72)
        txtCognome.Name = "txtCognome"
        txtCognome.Size = New Size(103, 27)
        txtCognome.TabIndex = 5
        ' 
        ' txtIndirizzo
        ' 
        txtIndirizzo.Location = New Point(301, 72)
        txtIndirizzo.Name = "txtIndirizzo"
        txtIndirizzo.Size = New Size(99, 27)
        txtIndirizzo.TabIndex = 6
        ' 
        ' txtTelefono
        ' 
        txtTelefono.Location = New Point(416, 73)
        txtTelefono.Name = "txtTelefono"
        txtTelefono.Size = New Size(104, 27)
        txtTelefono.TabIndex = 7
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(568, 77)
        Button1.Name = "Button1"
        Button1.Size = New Size(94, 29)
        Button1.TabIndex = 8
        Button1.Text = "Aggiungi"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' tabella
        ' 
        tabella.AllowUserToAddRows = False
        tabella.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        tabella.Location = New Point(44, 153)
        tabella.Name = "tabella"
        tabella.RowHeadersWidth = 51
        tabella.RowTemplate.Height = 29
        tabella.Size = New Size(476, 188)
        tabella.TabIndex = 10
        ' 
        ' Form11
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(tabella)
        Controls.Add(Button1)
        Controls.Add(txtTelefono)
        Controls.Add(txtIndirizzo)
        Controls.Add(txtCognome)
        Controls.Add(txtNome)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form11"
        Text = "rubrica"
        CType(tabella, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtNome As TextBox
    Friend WithEvents txtCognome As TextBox
    Friend WithEvents txtIndirizzo As TextBox
    Friend WithEvents txtTelefono As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents tabella As DataGridView
End Class
