﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Sapi
        Sapi = CreateObject("sapi.spvoice")
        Sapi.Speak("grazie maestro")
        Sapi.Speak("il mio unico maestro")
    End Sub
End Class
