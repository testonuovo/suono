﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Sapi
        Sapi = CreateObject("sapi.spvoice")
        Sapi.Speak("ti piace il regalo?")
        Sapi.Speak("ha la sua dignità")
    End Sub
End Class
