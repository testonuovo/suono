﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Sapi
        Sapi = CreateObject("sapi.spvoice")
        Sapi.Speak("ha la sua dignità")
    End Sub
End Class